# furryhk GitHub Pages

## 上传图片
放到 images 文件夹：

avatar.jpg 头像
wechat.png 微信二维码
qq.png QQ二维码
wechatpay.png 微信赞赏码
alipay.png 支付宝赞赏码

网站地址：
https://furryhk.github.io/furryhk/
